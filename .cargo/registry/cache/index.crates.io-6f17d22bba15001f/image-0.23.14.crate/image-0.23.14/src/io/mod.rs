//! Input and output of images.
mod reader;
pub(crate) mod free_functions;

pub use self::reader::Reader;

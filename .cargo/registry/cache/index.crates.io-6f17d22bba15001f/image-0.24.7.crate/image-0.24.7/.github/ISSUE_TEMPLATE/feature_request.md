---
name: Feature request
about: Enabling something that is not yet possible
labels: enhancement
title: ''
assignees: ''

---

<!-- Please fill out the relevant sections below, and delete all that do not apply: -->

I would like to be able ...

My specific use case for this functionality is ...

This is more generally applicable to ...

## Draft

<!-- Can you show a possible way to provide this functionality? Consider that a good
draft drastically reduces mental overhead, gives context, and overall makes it
much more likely to be implemented. The draft does not need to be an actual
implementation but should provide a starting point for discussion. -->


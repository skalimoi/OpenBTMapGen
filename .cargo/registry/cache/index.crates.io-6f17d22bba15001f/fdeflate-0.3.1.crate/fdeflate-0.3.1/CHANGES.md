# Changelog

## 0.3.1

- Strengthen postconditions on `Decompressor::read`.
- Add more fuzz testing.

## 0.3.0

- Added support for decoding arbitrary zlib streams.

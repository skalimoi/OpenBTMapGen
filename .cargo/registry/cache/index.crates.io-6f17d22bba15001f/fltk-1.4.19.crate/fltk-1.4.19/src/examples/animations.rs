//!Documentation for the `animations` example
//!
//!This is the documentation for the example `animations.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

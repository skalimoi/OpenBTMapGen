//!Documentation for the `widget_id` example
//!
//!This is the documentation for the example `widget_id.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.
//! ### Description
//! A simple counter, containing a button to increment and decrement each. It
//! accesses the frame via a widget id.

//!Documentation for the `editor` example
//!
//!This is the documentation for the example `editor.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.
//!It shows handling state via GlobalState and setting/getting widget ids, as well as structuring callbacks using function objects.

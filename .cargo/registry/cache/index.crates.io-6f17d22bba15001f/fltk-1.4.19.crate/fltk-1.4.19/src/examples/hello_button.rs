//!Documentation for the `hello_button` example
//!
//!This is the documentation for the example `hello_button.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

//! A simple counter.
//!
//!The code can be found in the `examples` directory next to the `src` directory in the source distribution.
//! ### Description
//! A simple counter, containing a button to increment and decrement each. It
//! uses a direct callback approach cloning the frame that shows the count.
//! Contains some theming.

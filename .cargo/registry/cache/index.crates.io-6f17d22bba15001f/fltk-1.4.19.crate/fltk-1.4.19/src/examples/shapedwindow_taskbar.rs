//!Documentation for the `shapedwindow_taskbar` example
//!
//!This is the documentation for the example `shapedwindow_taskbar.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

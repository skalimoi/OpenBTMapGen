//!Documentation for the `popup_browser` example
//!
//!This is the documentation for the example `popup_browser.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

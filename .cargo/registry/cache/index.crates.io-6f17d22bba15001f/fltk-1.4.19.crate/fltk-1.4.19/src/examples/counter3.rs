//!A a flutter-styled incrementing counter.
//!
//!The code can be found in the `examples` directory next to the `src` directory in the source distribution.
//!### Description
//!Contains a button for increment. Shows off flutter-like styling. Uses a
//!simple callback approach.

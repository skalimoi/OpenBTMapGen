//!Documentation for the `temp_converter2` example, which uses a different architecture than the temp_converter example
//!
//!This is the documentation for the example `temp_converter2.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

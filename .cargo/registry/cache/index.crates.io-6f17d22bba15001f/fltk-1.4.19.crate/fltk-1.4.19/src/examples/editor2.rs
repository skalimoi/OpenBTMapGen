//!Documentation for the `editor2` example
//!
//!This is the documentation for the example `editor2.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.
//!It shows usage of messages via the MenuExt::add_emit pattern.

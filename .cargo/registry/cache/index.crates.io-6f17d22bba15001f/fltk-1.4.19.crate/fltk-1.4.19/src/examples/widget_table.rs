//!Documentation for the `widget_table` example
//!
//!This is the documentation for the example `widget_table.rs`. The code can be found in the `examples` directory next to the `src` directory in the source distribution.

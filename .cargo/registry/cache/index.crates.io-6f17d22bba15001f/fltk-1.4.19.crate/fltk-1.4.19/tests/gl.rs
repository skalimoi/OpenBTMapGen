// use fltk::{enums::*, prelude::*, *};

fn main() {
    // let app = app::App::default();
    // let mut win = window::GlWindow::default().with_size(400, 300);
    // win.set_mode(Mode::MultiSample); // for antialiasing
    // win.set_frame(FrameType::FlatBox);
    // win.begin();
    // let mut dial =
    //     valuator::LineDial::new(100, 50, 200, 200, "Load %");
    // dial.set_selection_color(Color::Red);
    // dial.set_color(Color::Blue);
    // dial.set_value(0.5);
    // dial.set_frame(FrameType::OFlatFrame);
    // win.end();
    // win.show();
    // app.run().unwrap();
}
